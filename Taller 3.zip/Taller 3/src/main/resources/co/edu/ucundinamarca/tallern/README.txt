Apartado 4 (Punto 1) 
1. para que no se desborde  el factorial y la potencia tendremos que manejar numero pequeños 
con eso no se va a desbordar al momento de ejecutarlo 


Apartado 2 (Punto 2)
1. al codigo le hacian falta una condicional , donde se indica que el valor de "b" es igua la "0"
va a retorarnar el valo de a de lo contrario retornada el valor de "a" mod "b"
2. la condicion b == 0  se pone antes del "retunr mcd(b, a%b)"

Apartado 3 (Punto 2)
no tenia condicionales y al momento de ejecutarlo salia un error que se podia corregir usando 
una condicional y agregando un retorno 

Apartado 4 (Punto 2)
todo ejercicio tiene un proceso  y  para hallar el MCD no es la diferencia entonces esto es lo 
que ejecuta nuestro programa en un orden 
 
