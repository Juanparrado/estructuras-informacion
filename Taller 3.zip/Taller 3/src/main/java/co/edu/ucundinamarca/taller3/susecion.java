
package co.edu.ucundinamarca.taller3;


public class susecion {
   
    public static void main(String[] args) {
        
        susecion objBaj= new susecion();
        objBaj.bajar(10);
    }
    
    
    
    
    public void bajar(int numero){
        if (numero == 0){
            System.out.println("Finalizada");
        }else{
            System.out.println("S:"+ numero);
            
            bajar  (numero - 1) ;
        }
    }
}
